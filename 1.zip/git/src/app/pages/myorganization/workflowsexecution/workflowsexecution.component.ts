import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workflowsexecution',
  templateUrl: './workflowsexecution.component.html',
  styleUrls: ['./workflowsexecution.component.css']
})
export class WorkflowsexecutionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
