import { Component, OnInit } from '@angular/core';


import { FormBuilder, FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'app-process',
  templateUrl: './process.component.html',
  styleUrls: ['./process.component.css']
})
export class ProcessComponent implements OnInit {




  profileForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.profileForm = this.fb.group({
    
      outerField: this.fb.array([])
    });
  }

  
  get outerFieldsArray(): FormArray {
    return this.profileForm.get('outerField') as FormArray;
  }


  addOuterField(): void {
   
   
      this.outerFieldsArray.push(this.createOuterFieldFormGroup());
    
  }

  
  createOuterFieldFormGroup(): FormGroup {
    return this.fb.group({
     
      outerFieldName: [''], 
      innerField: this.fb.array([]) 
    });
  }
  removePhone(index:any ,j:any)
  {
   this.innerFieldsArray(index).removeAt(j)
  }
  removePhoneouter(index:any)
  {
    this.outerFieldsArray.removeAt(index)
  }
 
  createInnerFieldFormGroup() {
    return this.fb.group({
     
      innerFieldName: ['']
    });
  }
  innerFieldsArray(index: number): FormArray {
    return (this.outerFieldsArray.at(index).get('innerField') as FormArray);
  }
  
  addInnerField(outerIndex: number): void {
    const innerFieldsArray = this.outerFieldsArray.at(outerIndex).get('innerField') as FormArray;
    innerFieldsArray.push(this.createInnerFieldFormGroup());
  }
  onSubmit(){
     console.log(this.profileForm.value)
  }
  
}
