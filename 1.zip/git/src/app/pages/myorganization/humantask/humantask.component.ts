import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-humantask',
  templateUrl: './humantask.component.html',
  styleUrls: ['./humantask.component.css']
})
export class HumantaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
