import { Component, OnInit } from '@angular/core';
import { ColDef, GridOptions, RowClassParams } from 'ag-grid-community';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.css']
})
export class WorkflowComponent implements OnInit {

  constructor(private product:ProductService ) { }
user:any
rowData: any
isRowSelectable:any
  ngOnInit(): void {
    this.product.getUsers().subscribe((users: any) => {
      console.log(users)

        this.user = users.resData.data;
        this.rowData=users.resData.data
        console.log('Users:', this.user)
        this.rowData.forEach((item:any) => {
          item.is_table_exist = item.is_table_exist ? 'Yes' : 'No'
        
        });
       
      } 
      );
      }
   selectedRows:any
      colDefs: ColDef[] = [
        { headerName: '', checkboxSelection: true, headerCheckboxSelection: true, width: 50 },
        { headerName: 'TableName', field: 'table_name.value'},
        { headerName: 'Table Description', field: 'description.value' },
        { headerName: 'Existing in Product List', field: 'is_table_exist' },
    
      ];
      gridOptions: GridOptions = {

        suppressRowClickSelection: true,
        isRowSelectable: (params) => {
          const data = params.data;
          return data.is_table_exist === 'No'; 
        },
     getRowStyle:(params:RowClassParams)=>{
      const data = params.data;
    
      if (data.is_table_exist === 'Yes') {
        return { background: '#333333', color: 'white'}; 
      }

    return 
    },
     
    
        context: { parentComponent: this, parent: 'product' },
        
        
      };
 
   
    }
  
  
