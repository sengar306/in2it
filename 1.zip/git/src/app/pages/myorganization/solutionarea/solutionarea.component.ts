import { Component, OnInit } from '@angular/core';
import { ColDef, GridOptions , GridApi} from 'ag-grid-community';


import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-solutionarea',

  templateUrl: './solutionarea.component.html',
  styleUrls: ['./solutionarea.component.css']
})
export class SolutionareaComponent implements OnInit {
  constructor(
    private service: ServiceService,
   
  ) {
    this.service.contactSubject.subscribe((data: any) => {
      this.organization = data;
    });
  }
  organization:any
 rowData:any
   gridOption:GridOptions={}
  
  ngOnInit(): void {
    setTimeout(() => {
      this.gridOption.api?.sizeColumnsToFit()
      
    }, 0);
    this.rowData = this.organization.flatMap((org:any) =>
      org.contact.map((contact: any) => ({
      ...contact,organization:org.organization
      }))
    );
    console.log(this.rowData)
    
  }
  // Inside your method or constructor
 

  // Column Definitions: Defines the columns to be displayed.
  colDefs: ColDef[] = [
    { headerName: 'Organization', field: 'organization' ,checkboxSelection: true, headerCheckboxSelection: true },
    { headerName: 'Name', field: 'name' },
    { headerName: 'role', field: 'role' },
    { headerName: 'phone', field: 'phone' },
    { headerName:'email',field:'email'}
 

  ];
  
  
  onSelectionChanged(event: any) {
    const gridApi: GridApi = event.api;
    const selectedRows = gridApi.getSelectedRows();
    
    // Call your function based on the selection
    if (selectedRows.length > 0) {
      this.onCheckboxSelectionTrue();
    } else {
      this.onCheckboxSelectionFalse();
    }
  }
  onCheckboxSelectionTrue() {
    console.log("Checkbox selection is true.");
    // Call your function when checkbox selection is true
  }

  onCheckboxSelectionFalse() {
    console.log("Checkbox selection is false.");
    // Call your function when checkbox selection is false
  }
}


  
   

