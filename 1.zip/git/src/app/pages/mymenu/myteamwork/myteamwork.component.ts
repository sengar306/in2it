import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/service/service.service';
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';

@Component({
  selector: 'app-myteamwork',
  templateUrl: './myteamwork.component.html',
  styleUrls: ['./myteamwork.component.css'],
})
export class MyteamworkComponent implements OnInit {
  constructor(private service: ServiceService) {
    this.service.headerNav({ module: 'Mymenu', links: 'Myteam' });
  }

  ngOnInit(): void {}
  ngAfterViewInit() {
    let root = am5.Root.new('chartdiv');

    root.setThemes([am5themes_Animated.new(root)]);

    let chart = root.container.children.push(
      am5xy.XYChart.new(root, {
        panY: false,
        layout: root.horizontalLayout,
      })
    );
    root._logo?.dispose();
    // Define data
    let sales_ticket_per_owner = [
      {
        user_name: 'Vishal Mishra',
        total_ticket: 3,
      },
      {
        user_name: 'Pawna Kumare',
        total_ticket: 19,
      },
      {
        user_name: 'Shivank Tyagi',
        total_ticket: 36,
      },
      {
        user_name: 'Vikash Tiwari123',
        total_ticket: 6,
      },
      {
        user_name: 'Vikash Tiwari',
        total_ticket: 5,
      },
    ];
    let data = [
      {
        user_name: 'Vishal Mishra',
        total_ticket: 3,
      },
      {
        user_name: 'Pawna Kumare',
        total_ticket: 19,
      },
      {
        user_name: 'Shivank Tyagi',
        total_ticket: 36,
      },
      {
        user_name: 'Vikash Tiwari123',
        total_ticket: 6,
      },
      {
        user_name: 'Vikash Tiwari',
        total_ticket: 5,
      },
      {
        user_name: 'Ankit Tyagi',
        total_ticket: 90,
      },
      {
        user_name: 'vivek',
        total_ticket: 90,
      },
      {
        user_name: 'Vikash Tiwari123',
        total_ticket: 6,
      },
      {
        user_name: 'geeta',
        total_ticket: 5,
      },
      {
        user_name: 'seeta',
        total_ticket: 90,
      },
      {
        user_name: 'vineeta',
        total_ticket: 90,
      },
    ];

    let yAxis = chart.yAxes.push(
      am5xy.ValueAxis.new(root, {
        min: 0,
        max: 100,
        renderer: am5xy.AxisRendererY.new(root, {}),
        visible: false,
      })
    );
    yAxis.get('renderer').grid.template.setAll({ visible: false });
    let xAxis = chart.xAxes.push(
      am5xy.CategoryAxis.new(root, {
        renderer: am5xy.AxisRendererX.new(root, {}),
        categoryField: 'user_name',
      })
    );
    xAxis.get('renderer').grid.template.setAll({ visible: false });
    xAxis.data.setAll(sales_ticket_per_owner);

    let total_ticket = 'total_ticket';
    let user_name = 'user_name';
    let series1 = chart.series.push(
      am5xy.ColumnSeries.new(root, {
        name: 'Sale per ticket',
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: total_ticket,
        categoryXField: user_name,
        fill: am5.color(0x095256),
        stroke: am5.color(0x095256),
      })
    );
    series1.columns.template.setAll({
      width: am5.percent(10),
    });
    series1.data.setAll(sales_ticket_per_owner);
    series1.appear(1000, 100);

    //custom button
    var button = chart.plotContainer.children.push(
      am5.Button.new(root, {
        dx: 10,
        dy: 10,
        label: am5.Label.new(root, {
          text: 'Add data',
        }),
      })
    );

    button.events.on('click', function () {
      var last = series1.data.length;
      console.log(last);

      if (last < data.length) {
        console.log('add data');
        console.log(data[last + 1].user_name);
        series1.data.push({
          user_name: data[last + 1].user_name,
          total_ticket: data[last + 1].total_ticket,
        });
        console.log(sales_ticket_per_owner);
      } else {
        console.log('nodata');
      }
    });
  }
}
