import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ColDef, GridOptions } from 'ag-grid-community';

import { ProductService } from 'src/app/service/product.service';
import { InputRedererComponent } from 'src/app/shared/input-rederer/input-rederer.component';

import { ShareIconComponent } from 'src/app/shared/share-icon/share-icon.component';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent implements OnInit {
  gridApi: any;
  editIndex: any;
  user: any;
  rowData: any;
  data: any;
  iconchange!: boolean;
  params: any;
  updatedObj: any;
  selectedRows: any;
  constructor(private product: ProductService, private router: Router) {}

  ngOnInit(): void {
    this.selectedRows = window.history.state.data;
    console.log(this.selectedRows);
    this.getTableData();
  }

  getTableData() {
    // Fetch user data
    this.product.getUsers().subscribe((users: any) => {
      console.log('Users:', users);

      const filteredUsers = users.resData.data.filter(
        (item: any) => item.is_table_exist !== false
      );

      this.rowData = JSON.parse(JSON.stringify(filteredUsers));
      this.selectedRows.forEach((element: any) => {
        if (!element.table_id) {
          element.table_id = { value: Math.floor(Math.random() * 100) + 1 };
        }
      });
      console.log(this.selectedRows);
      this.rowData.push(...this.selectedRows);
      console.log('Updated RowData:', this.rowData);
    });
  }

  colDefs: ColDef<any>[] = [
    { headerName: 'TableID', field: 'table_id.value', editable: false },
    {
      headerName: 'TableName',
      field: 'table_name.value',
      cellRenderer: InputRedererComponent,
    },

    {
      headerName: 'Table Description',
      field: 'description.value',
      cellRendererFramework: InputRedererComponent,
    },
    { headerName: 'CreatedOn', field: 'created_on.value' },
    { headerName: 'CreatedBy', field: 'created_by.value' },
    { headerName: 'UpdateON', field: 'updated_on.value' },
    { headerName: 'UpdateBy', field: 'updated_by.value' },
    {
      headerName: 'ACTION',
      cellRendererFramework: ShareIconComponent,
      cellRendererParams: {
        onDeleteClicked: this.deleteFormData.bind(this),
        onEditClicked: this.isEdittoogle.bind(this),
        savedEditData: this.saveEditData.bind(this),
        closeEdit: this.closeEdit.bind(this),
        iconchange: false,
      },
    },
  ];
  closeEdit(params: any) {
    this.params = params;
    this.params.data.updatedData = this.params.data;

    this.params.data.edit = false;
  }
  deleteFormData(id: any) {
    confirm('Are you sure to delete the product');
    this.rowData = this.rowData.filter((item: any) => {
      return item.table_id.value !== id;
    });
  }

  isEdittoogle(params: any) {
    this.gridApi = params.api;
    console.log(params.data);
    this.params = params;
    this.params.data.edit = true;
    const Data = JSON.parse(JSON.stringify(this.params.data));

    this.params.data.updatedData = Data;
    console.log(this.params.data);
  }
  onBtStartEditing(rowIndex: number, colKey: any) {
    if (this.gridApi) {
      console.log(`Starting editing at rowIndex ${rowIndex}`);
      this.gridApi.setFocusedCell(rowIndex, colKey);
      this.gridApi.startEditingCell({
        rowIndex: rowIndex,
        colKey: colKey,
      });
    } else {
      console.warn('Grid API is not initialized yet.');
    }
  }

  onGridReady(params: any) {
    this.params = params;
    this.gridApi = params.api;
  }

  gridOptions: GridOptions = {
    context: { parentComponent: this, parent: 'product-details' },
    suppressClickEdit: true,
  };
  saveEditData() {
    this.params.data.edit = false;
    this.params.data.table_name.value =
      this.params.data.updatedData.table_name.value;
    this.params.data.description.value =
      this.params.data.updatedData.description.value;
    console.log('data', this.params.data);
    console.log('savedEditdata', this.params.data.updatedData);
  }
  back() {
    this.router.navigate(['/Product/products']);
  }
}
