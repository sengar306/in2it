import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputRedererComponent } from './input-rederer.component';

describe('InputRedererComponent', () => {
  let component: InputRedererComponent;
  let fixture: ComponentFixture<InputRedererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputRedererComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputRedererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
