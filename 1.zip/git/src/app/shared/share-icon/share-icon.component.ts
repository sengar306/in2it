import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { GridApi, ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-share-icon',
  templateUrl: './share-icon.component.html',
  styleUrls: ['./share-icon.component.css'],
})
export class ShareIconComponent implements OnInit, ICellRendererAngularComp {

  icon: boolean = false;
  params: any;
  gridapi!: GridApi;
  iconChange: boolean = false;
  inputValue: any;
  constructor() {}
  ngOnInit(): void {

  }

  agInit(params: ICellRendererParams): void {
    this.params = params;
    this.gridapi = params.api;
    this.inputValue = params.value
  }

  refresh(_params: ICellRendererParams): boolean {
    return true;
  }

  onDeleteClicked(): void {
    console.log('jnjsnajasasn');
    if (this.params.onDeleteClicked instanceof Function) {
      switch (true) {
        case this.params.context.parent == 'product-details':
          this.params.onDeleteClicked(this.params.data.table_id.value);
          break;
        case this.params.context.parent == 'tasks':
          this.params.onDeleteClicked(this.params.data.ID);
      }
    } else {
      console.error('Unable to access row data');
    }
  }

  onEditClicked(): void {
    // Emit an event or call a function when the button is clicked

    if (typeof this.params.onEditClicked === 'function') {
      switch (true) {
        case this.params.context.parent == 'product-details':
          this.iconChange = true;
          console.log('knxcjnj');
          this.params.onEditClicked(this.params);
          break;

        case this.params.context.parent == 'tasks':
          this.params.onEditClicked(this.params.data.ID);
          break;
      }
    }
  }
saveEditData() {
 console.log(this.params.data.updatedData)
 this.iconChange=false
 this.params.savedEditData(this.params);
  }
  closeEdit() {
    this.icon = false;
    console.log('jdnjsdnjsdnd');
    this.params.closeEdit(this.params);
    this.iconChange = false;
  }
}
