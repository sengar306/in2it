import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ColDef, GridApi, GridOptions } from 'ag-grid-community';
// import { MytaskComponent } from 'src/app/pages/mymenu/mytask/mytask.component';

import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
})
export class TableComponent implements OnInit {
  getContextMenuItems: any;
  organization: any;
  params:any
  context:any
  gridApi!: GridApi;
  searchQuery: string = '';
  parentComponent: any;
  @Input() gridOptions:GridOptions={}
  @Output() checkBoxEmitter: EventEmitter<any> = new EventEmitter();
  editType:any='fullRow'
  @Input() colDefs!: ColDef[];
  @Input() rowData: any;

  constructor(private service: ServiceService) {
    this.service.contactSubject.subscribe((data: any) => {
      this.organization = data;
     
    });
  }
  onGridReady(params: any) {
    this.gridApi=params.api
     this.params=params
    this.context = params.context;
    this.parentComponent = this.context.parentComponent;
  }
  ngOnInit(): void {
    setTimeout(() => {
      this.gridOptions.api?.sizeColumnsToFit();
    }, 0);

    console.log(this.rowData);
  }
  onCellClicked(event: any) {

    switch (true) {
      case (this.context.parent === 'contacts' && event.colDef.field=='name') :
      this.parentComponent.viewFormOpen(event.data,event.id)
      break;
      case (this.context.parent==='contacts'&& event.colDef.field=='organization'):
        this.parentComponent.goToComponent2(event.data)
      break;
      case(this.context.parent==='organizations' && event.colDef.field=='organization'  ):
        this.parentComponent.add(event.data.id,event.data)
        break;
     
      
    
    }   
  }
  public defaultColDef: ColDef = {
    filter: true,
    sortable:true
  
  };
  onCheckboxSelect(event: any) {
    if (this.gridApi) {
      const selectedRows = this.gridOptions.api?.getSelectedRows();
      console.log(event);
      this.checkBoxEmitter.emit(selectedRows);
    } else {
      console.warn('Grid API is not initialized yet.');
    }
  }
  onSearchInput(query: any) {
    // Check if gridApi is defined before using it
    if (this.gridApi) {
      // Apply the quick filter to the grid's data
      console.log(query.data)
      this.gridApi.setQuickFilter(query.data);
    } else {
      console.warn('Grid API is not initialized yet.');
    }
  }
  
}
